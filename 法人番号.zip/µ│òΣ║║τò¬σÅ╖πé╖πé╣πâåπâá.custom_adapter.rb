{
  title: '法人番号システム',

  connection: {
    fields: [
      { 
        name: "application_id",
        label: "アプリケーションID",
        control_type: "password",
        hint: "アプリケーションID発行届出書を提出した後、国税庁より届くアプリケーションID（13桁）をここにセット"
      },
      { 
        name: "web_api_version",
        label: "Web-APIバージョン",
        hint: "1,2,3,4のいずれか。(最新バージョン：4)",
        control_type: "select",
        pick_list: [
          ["Ver.1", "1"],
          ["Ver.2", "2"],
          ["Ver.3", "3"],
          ["Ver.4", "4"]
        ],
        default: "4"
      }
    ],
    authorization: {}
  },
  
  test: ->(connection) { true },
  
  methods: {
    parse_xml_to_hash: -> (data) {
      data.inject({}){ |hash, (key, value)|
        if value.is_a?(Array)
          if value[0].keys[0] == "content!"
            hash.merge(
              { key => value[0]["content!"] }
            )
          elsif value[0].keys == []
            hash.merge(
              { key => nil }
            )
          else
            hash.merge(
              {
                key => value.inject([]) { |hash2, value2|
                  hash2 << call("parse_xml_to_hash", value2)
                } 
              }
            )
          end
        else
          hash.merge(
            { key => call("parse_xml_to_hash", value) }
          )
        end
      }
    }
  },

  object_definitions: {
    search_conditions: {
      fields: ->() {
        [
          { 
            name: "name",
            label: "商号又は名称",
            type: "string",
            hint: "「検索対象」で「JIS 第一・第二水準 （あいまい検索）」（デフォルト）又は「JIS 第一～第四水準 （完全一致検索）」を選択した場合は全角文字、「英語表記 （英語表記登録情報検索）」を選択した場合は半角文字で入力してください。"
          },
          {
            name: "mode",
            label: "検索方式",
            control_type: "select",
            pick_list: "mode",
            hint: "「前方一致検索」は、検索時に法人種別（株式会社など）を除いた法人名の先頭から検索し、指定した文字列から始まる名称の法人情報を取得できます。<br>「部分一致検索」は、検索時に法人名全体を検索し、指定した文字列を含む名称の法人の情報を取得できます。部分一致検索では法人種別（株式会社など）を除く必要はありません。",
            toggle_hint: "Select from list",
            toggle_field: {
              name: "mode",
              label: "検索方式",
              type: "string",
              control_type: "text",
              toggle_hint: "Enter custom value",
              hint: "前方一致検索の場合「1」、部分一致検索の場合「2」"
            }
          },
          {
            name: "target",
            label: "検索対象",
            control_type: "select",
            pick_list: "target",
            toggle_hint: "Select from list",
            toggle_field: {
              name: "target",
              label: "検索対象",
              type: "string",
              control_type: "text",
              toggle_hint: "Enter custom value",
              hint: "JIS 第一・第二水準 （あいまい検索）の場合「1」、JIS 第一～第四水準 （完全一致検索）の場合「2」、英語表記 （英語表記登録情報検索）の場合「3」"
            }
          },
          {
            name: "address",
            label: "所在地",
            type: "integer",
            hint: "国内所在地の都道府県コード又は都道府県コードと市区町村コードを組み合わせたコードのいずれかを指定できます。市区町村コードのみではエラーとなります。都道府県コード及び市区町村コードの詳細については<a href='http://www.jisc.go.jp/', target=”_blank”>こちら</a>"
          },
          {
            name: "kind",
            label: "法人種別",
            control_type: "select",
            pick_list: "kind",
            hint: "何も指定しない場合は、全ての法人種別が含まれたデータが応答します。",
            toggle_hint: "Select from list",
            toggle_field: {
              name: "kind",
              label: "法人種別",
              type: "string",
              control_type: "text",
              toggle_hint: "Enter custom value",
              hint: "何も指定しない場合、全ての法人種別が含まれたデータが応答します。国の機関の場合「01」、地方公共団体の場合「02」、設立登記法人の場合「03」、外国会社等・その他の場合「04」"
            }
          },
          {
            name: "change",
            label: "変更履歴",
            control_type: "select",
            pick_list: "change",
            hint: "法人名や所在地の変更があった法人等について過去の情報を含めて検索するかどうかを指定できます。",
            toggle_hint: "Select from list",
            toggle_field: {
              name: "change",
              label: "変更履歴",
              type: "string",
              control_type: "text",
              toggle_hint: "Enter custom value",
              hint: "変更履歴を含めない場合「0」、変更履歴を含める場合「1」"
            }
          },
          {
            name: "close",
            label: "登記記録の閉鎖等",
            control_type: "select",
            pick_list: "close",
            hint: "登記記録の閉鎖等があった法人等の情報を取得するかどうかを指定できます。",
            toggle_hint: "Select from list",
            toggle_field: {
              name: "close",
              label: "登録記録の閉鎖等",
              type: "string",
              control_type: "text",
              toggle_hint: "Enter custom value",
              hint: "登記記録の閉鎖等を含めない場合「0」、登記記録の閉鎖等を含める場合「1」"
            }
          },
          {
            name: "from",
            label: "法人番号指定年月日開始日",
            type: "date",
            hint: "法人番号指定年月日開始日を指定した場合は、法人番号指定年月日終了日も指定してください。"
          },
          {
            name: "to",
            label: "法人番号指定年月日終了日",
            type: "date",
            hint: "法人番号指定年月日終了日を指定した場合は、法人番号指定年月日開始日も指定してください。"
          },
          {
            name: "divide",
            label: "分割番号",
            type: "integer",
            hint: "応答結果が2,000件を超過する場合に、リクエストの応答結果を分割して提供します。応答結果の分割では、分割されたファイルの総数（分母）にあたるデータ項目を「分割数」と定義し、分割されたファイルの通し番号（分子）を表すデータ項目を「分割番号」と定義しています。"
          }
        ]
      }
    },
    search_conditions_for_number: {
      fields: ->() {
        [
          { 
            name: "number",
            label: "法人番号",
            type: "integer",
            hint: "13桁の法人番号を指定します。カンマ区切りで複数（最大10件）の法人番号を指定できます。"
          },
          {
            name: "history",
            label: "変更履歴要否",
            control_type: "select",
            pick_list: "history",
            hint: "公表情報の変更履歴を取得するかどうかを指定できます。指定しない場合は「0」として処理され、リクエスト時点の最新情報のみ応答します。",
            toggle_hint: "Select from list",
            toggle_field: {
              name: "history",
              label: "変更履歴要否",
              type: "string",
              control_type: "text",
              toggle_hint: "Enter custom value",
              hint: "変更履歴なしの場合「0」、変更履歴ありの場合「1」。指定しない場合「0」として処理され、リクエスト時点の最新情報のみ応答します。"
            }
          }
        ]
      }
    },
    
    corporations_data: {
      fields: -> (){
        [
          {
            name: "corporations", 
            type: :array, 
            of: :object,
            properties: [
              {
                name: "lastUpdateDate",
                label: "最終更新年月日",
                type: "date"
              },
              {
                name: "count",
                label: "総件数",
                type: "integer"
              },
              {
                name: "divideNumber",
                label: "分割番号",
                type: "integer"
              },
              {
                name: "divideSize",
                label: "分割数",
                type: "integer"
              },
              {
                name: "corporation",
                label: "法人情報",
                type: :array,
                of: :object,
                properties: [
                  {
                    name: "sequenceNumber",
                    label: "一連番号",
                    type: "integer"
                  },
                  {
                    name: "corporateNumber",
                    label: "法人番号",
                    type: "integer"
                  },
                  {
                    name: "process",
                    label: "処理区分 ",
                    type: "integer"
                  },
                  {
                    name: "correct",
                    label: "訂正区分",
                    type: "integer"
                  },
                  {
                    name: "updateDate",
                    label: "更新年月日",
                    type: "date"
                  },
                  {
                    name: "changeDate",
                    label: "変更年月日",
                    type: "date"
                  },
                  {
                    name: "name",
                    label: "商号又は名称",
                    type: "string"
                  },
                  {
                    name: "nameImageId",
                    label: "商号又は名称イメージID",
                    type: "string"
                  },
                  {
                    name: "kind",
                    label: "法人種別",
                    type: "integer"
                  },
                  {
                    name: "prefectureName",
                    label: "国内所在地（都道府県）",
                    type: "string"
                  },
                  {
                    name: "cityName",
                    label: "国内所在地（市区町村）",
                    type: "string"
                  },
                  {
                    name: "streetNumber",
                    label: "国内所在地（丁目番地等）",
                    type: "string"
                  },
                  {
                    name: "addressImageId",
                    label: "国内所在地イメージID",
                    type: "string"
                  },
                  {
                    name: "prefectureCode",
                    label: "都道府県コード",
                    type: "integer"
                  },
                  {
                    name: "cityCode",
                    label: "市区町村コード",
                    type: "integer"
                  },
                  {
                    name: "postCode",
                    label: "郵便番号",
                    type: "integer"
                  },
                  {
                    name: "addressOutside",
                    label: "国外所在地",
                    type: "string"
                  },
                  {
                    name: "addressOutsideImageId",
                    label: "国外所在地イメージID",
                    type: "string"
                  },
                  {
                    name: "closeDate",
                    label: "登記記録の閉鎖等年月日",
                    type: "date"
                  },
                  {
                    name: "closeCause",
                    label: "登記記録の閉鎖等の事由",
                    type: "string"
                  },
                  {
                    name: "successorCorporateNumber",
                    label: "承継先法人番号",
                    type: "integer"
                  },
                  {
                    name: "changeCause",
                    label: "変更事由の詳細",
                    type: "string"
                  },
                  {
                    name: "assignmentDate",
                    label: "法人番号指定年月日",
                    type: "date"
                  },
                  {
                    name: "latest",
                    label: "最新履歴",
                    type: "integer"
                  },
                  {
                    name: "enName",
                    label: "商号又は名称（英語表記）",
                    type: "string"
                  },
                  {
                    name: "enPrefectureName",
                    label: "国内所在地（都道府県）（英語表記）",
                    type: "string"
                  },
                  {
                    name: "enCityName",
                    label: "国内所在地（市区町村丁目番地等）（英語表記）",
                    type: "string"
                  },
                  {
                    name: "enAddressOutside",
                    label: "国外所在地（英語表記）",
                    type: "string"
                  },
                  {
                    name: "furigana",
                    label: "フリガナ",
                    type: "string"
                  },
                  {
                    name: "hihyoji",
                    label: "検索対象除外",
                    type: "integer"
                  }
                ]
              }
            ]
          } 
        ]
      }
    }
  },
  
  pick_lists: {
    mode: ->(){
      [
        ["前方一致検索","1"],
        ["部分一致検索","2"]
      ]
    },
    target: ->(){
      [
        ["JIS 第一・第二水準 （あいまい検索）", "1"],
        ["JIS 第一～第四水準 （完全一致検索）", "2"],
        ["英語表記 （英語表記登録情報検索）", "3"]
      ]
    },
    kind: ->(){
      [
        ["国の機関", "01"],
        ["地方公共団体", "02"],
        ["設立登記法人", "03"],
        ["外国会社等・その他", "04"]
      ]
    },
    change: ->(){
      [
        ["変更履歴を含めない", "0"],
        ["変更履歴を含める", "1"]
      ]
    },
    close: ->(){
      [
        ["登記記録の閉鎖等を含めない", "0"],
        ["登記記録の閉鎖等を含める", "1"]
      ]
    },
    history: ->(){
      [
        ["変更履歴なし", "0"],
        ["変更履歴あり", "1"]
      ]
    },
    web_api_version: ->(){
      [
        ["Ver.1", "1"],
        ["Ver.2", "2"],
        ["Ver.3", "3"],
        ["Ver.4", "4"]
      ]
    }
  },
  
  actions: {
    search_records_by_corporation_name: {
      title: "法人名を指定して情報を取得",
      input_fields: ->(object_definitions) {
        object_definitions['search_conditions'].required('name')
      },
      
      execute: ->(connection, input) {
        response = get("https://api.houjin-bangou.nta.go.jp/#{connection['web_api_version']}/name?id=#{connection['application_id']}&name=#{input['name'].encode_url}&type=12&mode=#{input['mode']}&target=#{input['target']}&address=#{input['所在地']}&kind=#{input['kind']}&change=#{input['change']}&close=#{input['close']}&from=#{input['from'].blank? ? '':input['from'].strftime('%Y-%m-%d')}&to=#{input['to'].blank? ? '':input['to'].strftime('%Y-%m-%d')}&divide=#{input['divide']}").response_format_xml
        call('parse_xml_to_hash', response)
      },
      
      output_fields: ->(object_definitions) {
        object_definitions['corporations_data']
      }
    },
    search_records_by_corporation_number: {
      title: "法人番号を指定して情報を取得",
      input_fields: ->(object_definitions) {
        object_definitions['search_conditions_for_number'].required('number')
      },
      
      execute: ->(connection, input) {
        response = get("https://api.houjin-bangou.nta.go.jp/#{connection['web_api_version']}/num?id=#{connection['application_id']}&number=#{input['number']}&type=12&history=#{input['history']}").response_format_xml
        call('parse_xml_to_hash', response)
      },
      
      output_fields: ->(object_definitions) {
        object_definitions['corporations_data']
      }
    }
  }
}