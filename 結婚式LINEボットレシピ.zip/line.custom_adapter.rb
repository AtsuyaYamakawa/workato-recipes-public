{
  title: 'LINE',

  connection: {
    fields: [
      {
        name: "client_id",
        hint: "Find client ID <a href='https://developers.line.biz/console/'target='_blank'>here</a>",
        optional: false
      },
      {
        name: "client_secret",
        hint: "Find client secret <a href='https://developers.line.biz/console/'target='_blank'>here</a>",
        optional: false,
        control_type: "password"
      }
    ],

    authorization: {
      type: 'custom_auth',
      
      acquire: lambda do |connection|
        response = post("https://api.line.me/v2/oauth/accessToken").
                     headers("Content-Type": "application/x-www-form-urlencoded").
                     payload(client_id: connection["client_id"],
                             client_secret: connection["client_secret"],
                             grant_type: "client_credentials").
                     request_format_www_form_urlencoded
      end,

      refresh_on: [401],

      apply: lambda do |response|
        headers("Authorization": "Bearer #{response['access_token']}")
      end
    },

    base_uri: lambda do |connection|
      'https://api.line.me/'
    end
  },

  test: lambda do |connection|
    get('v2/bot/insight/demographic')
  end,

  actions: {
    send_message: {
      title: "Send text message / テキストメッセージの送信",
      subtitle: "Send a text message to a user, group chat, or multi-person chat in " \
      "<span class='provider'>LINE</span> / <span class='provider'>LINE</span>" \
      "でユーザ・グループ・トークにテキストメッセージを送信する",
      description: "Send a message in <span class='provider'>LINE</span>" \
      " / <span class='provider'>LINE</span>にメッセージを送信する",
      help: "<p><b>Conditions for sending push message</b><br>" \
      "You can send a push message under one of the following conditions:<br>"\
      " - Users who have added your LINE Official Account as a friend<br>" \
      " - Group chats or multi-person chats which your LINE Official " \
      "Account has been joined<br>" \
      " - Users who have sent a message to your LINE Official Account within "\
      "7 days in the one-to-one chat (*)<br>" \
      "When you send a push message to these users, status code 200 will " \
      "be returned, but the users won't receive the message:<br>" \
      " - Users who deleted their LINE accounts<br>" \
      " - Users who blocked the LINE Official Account from which the push " \
      "message was sent<br>" \
      " - Users who haven't added your LINE Official Account as a friend (*)<br>" \
      "*Users can also send a message to your LINE Official Account which " \
      "they haven't added as a friend. If your LINE Official Account receives " \
      "a message in the one-to-one chat from a user who hasn't been a friend " \
      "of yours, you can send a push message to the user within 7 days of " \
      "receiving the message.</p>" \
      "<p><b>プッシュメッセージの送信条件</b><br>" \
      "プッシュメッセージの送信は、以下の条件で行うことができます。<br>" \
      " - LINE公式アカウントを友だちに追加しているユーザー<br>" \
      " - あなたのLINE公式アカウントが参加しているグループチャットや複数人" \
      "でのチャット<br>" \
      " - 1対1のトークで、7日以内にあなたのLINE公式アカウントにメッセージを" \
      "送信したことがあるユーザー(※)<br>" \
      "これらのユーザーにプッシュメッセージを送信した場合、ステータスコード" \
      "200が返されますが、メッセージは届きません。<br>" \
      " - LINEアカウントを削除したユーザー<br>" \
      " - プッシュメッセージの送信元であるLINE公式アカウントをブロック" \
      "しているユーザー<br>" \
      " - LINE公式アカウントを友だち登録していないユーザー (※)<br>" \
      "*友だちになっていないLINE公式アカウントにメッセージを送信することも" \
      "できます。LINE公式アカウントが友だちになっていないユーザーから1対1の" \
      "トークでメッセージを受け取った場合、メッセージを受け取ってから7日以内" \
      "であれば、そのユーザーに対してプッシュメッセージを送信することができます。</p>",

      input_fields: lambda do |object_definitions, connection, config_fields|
        [
          {
            name: "messages",
            label: "Messages / メッセージ",
            optional: false,
            type: "array",
            of: "object",
            properties: object_definitions['text']
          },
          {
            name: "to",
            label: "To / 送信先",
            optional: false,
            hint: "ID of the target recipient. Use a userId, groupId, or "\
            "roomId value returned in a webhook event object"
          },
          {
            name: "notificationDisabled",
            label: "Notification Disabled / 通知オフ",
            optional: true,
            hint: "true: The user doesn't receive a push notification when " \
            "the message is sent.<br>" \
            "false: The user receives a push notification when the message " \
            "is sent (unless they have disabled push notifications in LINE " \
            "and/or their device).<br>" \
            "Default: false"
          }
        ]
      end,

      execute: lambda do |connection, input|
        messages = []

        input[:messages].each{|message|
          messages << message.merge({type: 'text'})
        }

        input.merge({messages: messages})

        post("https://api.line.me/v2/bot/message/push", input.except('message_type').
          merge(messages: messages)).
          after_error_response(/.*/) do |_, body, _, message|
            error("#{message}: #{body}")
          end
      end,

      output_fields: lambda do |_object_definitions|
      end
    },

    send_flex_message: {
      title: "Send Flex message / フレックスメッセージの送信",
      subtitle: "Send a Flex message to a user, group chat, or multi-person chat" \
      " in <span class='provider'>LINE</span> / <span class='provider'>LINE" \
      "</span>でユーザ・グループ・トークにフレックスメッセージを送信する",
      description: "Send a Flex message in <span class='provider'>LINE</span>" \
      " / <span class='provider'>LINE</span>にフレックスメッセージを送信する",
      help: "",
      
      config_fields: [
        {
          name: "input_type",
          label: "Input type",
          control_type: "select",
          pick_list: "input_types",
          optional: false
        }
      ],

      input_fields: lambda do |object_definitions, connection, config_fields|
        input_type = config_fields['input_type']
        object_definitions[input_type].push(
          {
            name: "to",
            label: "To / 送信先",
            optional: false,
            hint: "ID of the target recipient. Use a userId, groupId, or "\
            "roomId value returned in a webhook event object"
          },
          {
            name: "notificationDisabled",
            label: "Notification Disabled / 通知オフ",
            optional: true,
            hint: "true: The user doesn't receive a push notification when " \
            "the message is sent.<br>" \
            "false: The user receives a push notification when the message " \
            "is sent (unless they have disabled push notifications in LINE " \
            "and/or their device).<br>" \
            "Default: false"
          }
        )
      end,

      execute: lambda do |connection, input|
        messages = []
        
        if input[:request_body].present?
          messages << {type: 'flex', altText: '新規メッセージ', contents: input[:request_body]}
        elsif
          input[:messages].each{|message|
            messages << message.merge({type: 'flex', altText: '新規メッセージ'})
          }
        end

        input.merge({messages: messages})
        
        post("https://api.line.me/v2/bot/message/push", input.except('input_type', 'request_body_schema', 'request_body').
          merge(messages: messages)).
          after_error_response(/.*/) do |_, body, _, message|
            error("#{message}: #{body}")
          end
      end,

      output_fields: lambda do |_object_definitions|
      end
    },

    get_content: {
      title: "Get content / コンテンツの取得",
      subtitle: "Gets images, videos, audio, and files received via the " \
      "webhook in <span class='provider'>LINE</span> / <span class='provider'>" \
      "LINE</span>でWebhookで受け取ったコンテンツを取得する",
      description: "Get content in <span class='provider'>LINE</span> / " \
      "<span class='provider'>LINE</span>でコンテンツを取得する",
      help: "<p>Gets images, videos, audio, and files sent by users using " \
      "message IDs received via the webhook. </p><p>Webhookで受信したメッセージ" \
      "IDを使って、ユーザーが送信した画像、動画、音声、ファイルを取得します。</p>",

      input_fields: lambda do |object_definitions, connection, config_fields|
        [
          {
            name: "message_id",
            label: "Message ID / メッセージID",
            type: "string",
            optional: false,
            hint: "Webhookイベントのmessageオブジェクト内から取得できるID"
          }
        ]
      end,

      execute: lambda do |connection, input|
        #different base uri
        get("https://api-data.line.me/v2/bot/message/#{input["message_id"]}/content").
          response_format_raw.
          after_response do |code, body, headers|
          {
            mime: headers['content_type'],
            content: body
          }
        end
      end,

      output_fields: lambda do |_object_definitions|
        [
          {
            name: "mime",
            label: "MIME"
          },
          {
            name: "content",
            label: "Content"
          }
        ]
      end,

      sample_output: lambda do |_object_definitions|
        {
          mime: "image/jpeg",
          content: "<binary_data>"
        }
      end
    }
  },

  triggers: {
    new_message: {
      title: 'New event',

      subtitle: "Triggers when an event is received from LINE",

      description: lambda do |input, picklist_label|
        "New <span class='provider'>event</span> in " \
        "<span class='provider'>LINE</span>"
      end,

      help: "Triggers when webhook is sent from LINE.",

      input_fields: lambda do |object_definitions|
      end,

      webhook_subscribe: lambda do |webhook_url, connection, input, recipe_id|
        put("https://api.line.me/v2/bot/channel/webhook/endpoint",
             endpoint: webhook_url)
      end,

      webhook_notification: lambda do |input, payload, extended_input_schema, extended_output_schema, headers, params|
        payload
      end,

      webhook_unsubscribe: lambda do |webhook_subscribe_output, connection|
      end,

      dedup: lambda do |message|
        message
      end,

      output_fields: lambda do |object_definitions|
        [
          {
            "control_type": "text",
            "label": "Destination",
            "type": "string",
            "name": "destination"
          },
          {
            "name": "events",
            "type": "array",
            "of": "object",
            "label": "Events",
            "properties": [
              {
                "control_type": "text",
                "label": "Type",
                "type": "string",
                "name": "type"
              },
              {
                "label": "Message",
                "type": "object",
                "name": "message",
                "properties": [
                  {
                    "label": "Type",
                    "type": "string",
                    "name": "type"
                  },
                  {
                    "label": "ID",
                    "type": "string",
                    "name": "id"
                  },
                  {
                    "label": "Text",
                    "type": "string",
                    "name": "text"
                  },
                  {
                    "label": "Content provider",
                    "type": "object",
                    "name": "contentProvider",
                    "properties": [
                      {
                        "label": "Type",
                        "type": "string",
                        "name": "type"
                      }
                    ]
                  }
                ]
              },
              {
                "label": "Postback",
                "type": "object",
                "name": "postback",
                "properties": [
                  {
                    "control_type": "text",
                    "label": "Data",
                    "type": "string",
                    "name": "data"
                  }
                ]
              },
              {
                "control_type": "text",
                "label": "Webhook event ID",
                "type": "string",
                "name": "webhookEventId"
              },
              {
                "label": "Delivery context",
                "type": "object",
                "name": "deliveryContext",
                "properties": [
                  {
                    "control_type": "select",
                    "label": "Is redelivery",
                    "toggle_hint": "Select from option list",
                    "toggle_field": {
                      "name": "isRedelivery",
                      "label": "Is redelivery",
                      "control_type": "text",
                      "toggle_hint": "Use custom value",
                      "type": "boolean"
                    },
                    "pick_list": [
                      [
                        "True",
                        "true"
                      ],
                      [
                        "False",
                        "false"
                      ]
                    ],
                    "type": "boolean",
                    "name": "isRedelivery",
                    "convert_input": "boolean_conversion",
                    "convert_output": "boolean_conversion"
                  }
                ]
              },
              {
                "control_type": "number",
                "label": "Timestamp",
                "type": "number",
                "name": "timestamp",
                "convert_input": "integer_conversion",
                "convert_output": "integer_conversion"
              },
              {
                "label": "Source",
                "type": "object",
                "name": "source",
                "properties": [
                  {
                    "control_type": "text",
                    "label": "Type",
                    "type": "string",
                    "name": "type"
                  },
                  {
                    "control_type": "text",
                    "label": "Group ID",
                    "type": "string",
                    "name": "groupId"
                  },
                  {
                    "control_type": "text",
                    "label": "User ID",
                    "type": "string",
                    "name": "userId"
                  }
                ]
              },
              {
                "control_type": "text",
                "label": "Reply token",
                "type": "string",
                "name": "replyToken"
              },
              {
                "control_type": "text",
                "label": "Mode",
                "type": "string",
                "name": "mode"
              }
            ]
          }
        ]
      end,

      sample_output: lambda do |_connection, _input|
        {
          "destination": "Ueb4b2020b68c4d3b08ee1b1858567551",
          "events": [
            {
              "type": "message OR postback",
              "message": {
                "type": "text",
                "id": "16790525897440",
                "text": "hello!"
              },
              "postback": {
                "data": "submit"
              },
              "webhookEventId": "01GD219B4GVXVND415FNV9WA8Y",
              "deliveryContext": {
                "isRedelivery": false
              },
              "timestamp": 1663294548670,
              "source": {
                "type": "group",
                "groupId": "C1e162769c0823041cc2c3987c4efe1fd",
                "userId": "Ud160f2c8141e22f6f7bb1ae0897a8755"
              },
              "replyToken": "62b99a33d9d6495790a3023d7ada6c51",
              "mode": "active"
            }
          ]
        }
      end
    }
  },

  custom_action: true,

  custom_action_help: {
    learn_more_url: "https://developers.line.biz/en/reference/messaging-api/",

    learn_more_text: "Messaging API reference",

    body: "LINE Messaging APIで提供されているAPIをカスタムアクションを使用して" \
    "自由に呼び出せます。"
  },

  methods: {

  },

  object_definitions: {
#     message: {
#       fields: lambda do |_connection, _config_fields|
#         [
#           {
#             name: 'quickReply',
#             type: "object",
#             optional: false,
#             properties: [
#               {
#                 name: "items",
#                 type: "array",
#                 of: "object",
#                 hint: "最大オブジェクト数：13",
#                 properties:[
#                   {
#                     name: "type",
#                     type: "string",
#                     hint: "常にaction?"
#                   },
#                   {
#                     name: "imageUrl",
#                     type: "string",
#                     hint: "ボタンの先頭に表示するアイコンのURL。最大文字数：1000、URLスキーム：https、画像フォーマット：PNG、アスペクト比：1：1、最大データサイズ：1MB"
#                   },
#                   {
#                     name: "action",
#                     type: "object",
#                     hint: "アクションオブジェクトの指定",
#                     properties: [
#                       {
#                         name: "type",
#                         type: "string"
#                       },
#                       {
#                         name: "label",
#                         type: "string"
#                       }
#                     ]
#                   }
#                 ]
#               }
#             ]
#           }
#         ]
#       end
#     },

    text: {
      fields: lambda do |connections, config_fields|
        [
          {
            name: "text",
            label: "Text / テキスト",
            optional: false,
            control_type: "text-area",
            hint: "Message text. You can include the following emoji:" \
            " - LINE emojis. Use a $ character as a placeholder and specify " \
            "the product ID and emoji ID of the LINE emoji you want to use in " \
            "the emojis property. For more information, see List of available " \
            "LINE emojis.<br>" \
            " - Unicode emojis<br>" \
            "Max character limit: 5000"
          },
          {
            name: "emojis",
            label: "Emojis / 絵文字",
            type: "array",
            of: "object",
            optional: true,
            hint: "One or more LINE emoji.<br>Max: 20 LINE emoji",
            properties: [
              {
                name: "index",
                label: "Index",
                optional: true
              },
              {
                name: "productId",
                label: "Product ID",
                optional: true
              },
              {
                name: "emojiId",
                label: "Emoji ID",
                optional: true
              }
            ]
          }
        ]
      end
    },

    define_schema: {
      fields: lambda do |connections, config_fields|
        input_schema = parse_json(config_fields.dig('request_body_schema') || '[]')
        [
          {
            name: 'request_body_schema',
            extends_schema: true,
            schema_neutral: false,
            optional: false,
            control_type: 'schema-designer',
            label: 'Request body schema / リクエストボディのデータ構造',
            hint: "Define request body schema. / リクエストボディのデータ構造を設定します。<br>" \
              "<a href='https://developers.line.biz/flex-simulator/' target='_blank'>" \
              "Flex Message Simulator</a>",
            item_label: 'button',
            add_field_label: 'Add field',
            empty_schema_message: 'Use <button type="button" data-action="generateSchema">sample JSON</button> instead',
            sample_data_type: 'json_input' # json_input / xml
          },
          if input_schema.present?
            {
              name: 'request_body',
              label: 'Request body / リクエストボディ',
              type: 'object',
              properties: input_schema
            }
          end
        ].compact
      end
    },
    
    raw_json: {
      fields: lambda do |connections, config_fields|
        [
          {
            name: "messages",
            label: "Messages / メッセージ",
            optional: false,
            type: "array",
            of: "object",
            properties: [
              {
                name: 'contents',
                label: 'Request body',
                type: 'string',
                optional: false,
                control_type: 'text-area',
                hint: "Define request body. / リクエストボディを設定します。<br>" \
                  "<a href='https://developers.line.biz/flex-simulator/' target='_blank'>" \
                  "Flex Message Simulator</a>"
              }
            ]
          }
        ]
      end
    }
  },

  pick_lists: {
    message_types: lambda do
      [
        ["Text message", "text"]
      ]
    end,
    input_types: lambda do
      [
        ["Define schema", "define_schema"],
        ["Raw JSON", "raw_json"]
      ]
    end,
    size: lambda do
    [
      ["Nano", "nano"],
      ["Micro", "micro"],
      ["Kilo", "kilo"],
      ["Mega", "mega"],
      ["Giga", "giga"]
    ]
    end
  }
}

